DietSense DIC4 After
Main document: main.tex
Compiler: pdfLaTeX
All citations are embedded; no BibTeX pass is needed.
This is a proposed design and evaluation protocol without experiment results.
